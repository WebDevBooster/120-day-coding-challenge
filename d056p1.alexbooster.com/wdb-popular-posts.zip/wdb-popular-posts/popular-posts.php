<?php
/**
 * Plugin Name: WDB Popular Posts
 * Description: Simple plugin to count post views and display popular posts (sorted by view numbers) in a widget.
 * Version: 0.1
 * Author: WebDevBooster (Alex Booster)
 * Author URI: https://alexbooster.com
 * License: GPL2
 */

// block direct access to this PHP file
defined( 'ABSPATH' ) or die( 'No direct access!' );


/** 
* Post Popularity Counter
*/
function wdb_popular_post_views($postID) {
    $total_key = "views";
    // Get current "views" field 
    $total = get_post_meta( $postID, $total_key, true );
    // If current "views" field is empty, set it to zero
    if ( $total == "" ) {
        delete_post_meta( $postID, $total_key );
        add_post_meta( $postID, $total_key, "0" );
    } else {
        // If current "views" field has a value, add 1 to that
        $total++;
        update_post_meta( $postID, $total_key, $total );
    }
}
    

/** 
* Dynamically inject counter into single posts
*/
function wdb_count_popular_posts($post_id) {
    // Check that this is a single post and that the user is a visitor i.e. not logged in user
    if ( !is_single() ) return;
    if ( !is_user_logged_in() ) {
        // Get the post ID
        if ( empty ( $post_id ) ) {
            global $post;
            $post_id = $post->ID;
        }
        // Run Post Popularity counter on this post
        wdb_popular_post_views($post_id);
    }
}
    
add_action( "wp_head", "wdb_count_popular_posts");

/** 
* Add popular post function data to "All Posts" table in the WP admin area
*/

// add new column with the machine name "post_views":
function wdb_add_views_column($defaults) {
    $defaults["post_views"] = "View Count";
    return $defaults;
}

add_filter( "manage_posts_columns", "wdb_add_views_column" );

// populate the column with the numbers from our custom field: 
function wdb_display_views($column_name) {
    if ( $column_name === "post_views" ) {
        echo (int) get_post_meta( get_the_ID(), "views", true ) ;
    }
}

add_action( "manage_posts_custom_column", "wdb_display_views", 5, 2 );


/**
 * Adds WDB Popular Posts widget.
 */
class wdb_popular_posts extends WP_Widget {

    /**
	 * Register widget with WordPress.
	 */
    function __construct() {
        parent::__construct(
            'wdb_popular_posts', // Base ID
            esc_html__( 'WDB Popular Posts', 'text_domain' ), // Name
            array( 'description' => esc_html__( 'Displays the 5 most popular posts', 'text_domain' ), ) // Args
        );
    }

    /**
	 * Front-end display of widget.
	 *
	 * @see WP_Widget::widget()
	 *
	 * @param array $args     Widget arguments.
	 * @param array $instance Saved values from database.
	 */
    public function widget( $args, $instance ) {
        echo $args['before_widget'];
        if ( ! empty( $instance['title'] ) ) {
            echo $args['before_title'] . apply_filters( 'widget_title', $instance['title'] ) . $args['after_title'];
        }
//        echo esc_html__( 'Hello, World!', 'text_domain' );
        
        // My custom WP Query:
        
        $wdb_query_args = array(
            "post_type" => "post",
            "posts_per_page" => 5,
            "meta_key" => "views",
            "orderby" => "meta_value_num",
            "order" => "DESC",
            "ignore_sticky_posts" => true
        );
        
            $the_query = new WP_Query( $wdb_query_args );

        // The Loop
        if ( $the_query->have_posts() ) {
            echo '<ul>';
            while ( $the_query->have_posts() ) {
                $the_query->the_post();
                echo '<li>';
                echo '<a href="' . get_the_permalink() . '" rel="bookmark">';
                echo get_the_title();
                echo ' [' . get_post_meta( get_the_ID(), 'views', true ) . ' views]';
                echo '</a>';
                echo '</li>';
            }
            echo '</ul>';
            /* Restore original Post Data */
            wp_reset_postdata();
        } else {
            // no posts found
        }
        
        
        
        
        
        echo $args['after_widget'];
    }

    /**
	 * Back-end widget form.
	 *
	 * @see WP_Widget::form()
	 *
	 * @param array $instance Previously saved values from database.
	 */
    public function form( $instance ) {
        $title = ! empty( $instance['title'] ) ? $instance['title'] : esc_html__( 'WDB Popular Posts', 'text_domain' );
?>
<p>
    <label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_attr_e( 'Title:', 'text_domain' ); ?></label> 
    <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>">
</p>
<?php 
    }

    /**
	 * Sanitize widget form values as they are saved.
	 *
	 * @see WP_Widget::update()
	 *
	 * @param array $new_instance Values just sent to be saved.
	 * @param array $old_instance Previously saved values from database.
	 *
	 * @return array Updated safe values to be saved.
	 */
    public function update( $new_instance, $old_instance ) {
        $instance = array();
        $instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';

        return $instance;
    }

} // class wdb_popular_posts


// register WDB Popular Posts widget
function register_wdb_popular_posts() {
    register_widget( 'wdb_popular_posts' );
}
add_action( 'widgets_init', 'register_wdb_popular_posts' );


