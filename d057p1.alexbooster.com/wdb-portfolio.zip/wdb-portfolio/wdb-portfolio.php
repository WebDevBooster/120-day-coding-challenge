<?php
/*
Plugin Name:  WDB Portfolio Plugin
Description:  Custom WebDevBooster Portfolio Plugin
Version:      1.0.0
Author:       WebDevBooster (Alex Booster)
Author URI:   https://alexbooster.com
License:      GPL2
License URI:  https://www.gnu.org/licenses/gpl-2.0.html
Text Domain:  wdb-portfolio
Domain Path:  /lang
*/

// block direct access to this file
if ( !defined( 'ABSPATH' ) ) exit;

/** 
* Register WDB Portfolio post type
* 
* @see: 
* https://developer.wordpress.org/reference/functions/register_post_type/#comment-351
*/

function wdbpp_register_post_type() {
    $labels = array(
        'name'                  => _x( 'Portfolio', 'Post type general name', 'wdb-portfolio' ),
        'singular_name'         => _x( 'Portfolio Item', 'Post type singular name', 'wdb-portfolio' ),
        'menu_name'             => _x( 'WDB Portfolio', 'Admin Menu text', 'wdb-portfolio' ),
        'name_admin_bar'        => _x( 'WDB Portfolio Item', 'Add New on Toolbar', 'wdb-portfolio' ),
        'add_new'               => __( 'Add New Item', 'wdb-portfolio' ),
        'add_new_item'          => __( 'Add New Portfolio Item', 'wdb-portfolio' ),
    );
    
    $args = array(
        'labels'             => $labels,
        'public'             => true,
        'publicly_queryable' => true,
        'show_ui'            => true,
        'show_in_menu'       => true,
        'query_var'          => true,
        'rewrite'            => array( 'slug' => 'portfolio' ),
        'capability_type'    => 'post',
        'has_archive'        => true,
        'hierarchical'       => false,
        'menu_position'      => 5,
        'supports'           => array( 'title', 'editor', 'author', 'thumbnail', 'excerpt', 'comments' ),
        'menu_icon'          => 'dashicons-portfolio',
    );
    
    register_post_type( 'wdb_portfolio', $args );
}
add_action( 'init', 'wdbpp_register_post_type' );


/**
 * Create 3 taxonomies: Project Types, Utilized Technologies and Contributors for the post type "WDB Portfolio".
 *
 * @see register_post_type() for registering custom post types:
 * https://developer.wordpress.org/reference/functions/register_taxonomy/#comment-397
 */
function wdb_create_portfolio_taxonomies() {
    // Add new Project Types taxonomy, make it hierarchical (like categories)
    $labels = array(
        'name'              => _x( 'Project Types', 'taxonomy general name', 'wdb-portfolio' ),
        'singular_name'     => _x( 'Project Type', 'taxonomy singular name', 'wdb-portfolio' ),
        'search_items'      => __( 'Search Project Types', 'wdb-portfolio' ),
        'all_items'         => __( 'All Project Types', 'wdb-portfolio' ),
        'parent_item'       => __( 'Parent Project Type', 'wdb-portfolio' ),
        'parent_item_colon' => __( 'Parent Project Type:', 'wdb-portfolio' ),
        'edit_item'         => __( 'Edit Project Type', 'wdb-portfolio' ),
        'update_item'       => __( 'Update Project Type', 'wdb-portfolio' ),
        'add_new_item'      => __( 'Add New Project Type', 'wdb-portfolio' ),
        'new_item_name'     => __( 'New Project Type Name', 'wdb-portfolio' ),
        'not_found'         => __( 'No project types found.', 'wdb-portfolio' ),
        'menu_name'         => __( 'Project Types', 'wdb-portfolio' ),
    );

    $args = array(
        'hierarchical'      => true,
        'labels'            => $labels,
        'show_ui'           => true,
        'show_admin_column' => true,
        'query_var'         => true,
        'rewrite'           => array( 'slug' => 'project-type' ),
    );

    register_taxonomy( 'project_type', array( 'wdb_portfolio' ), $args );

    unset( $args );
    unset( $labels );

    // Add new Utilized Technologies taxonomy, NOT hierarchical (like tags)
    $labels = array(
        'name'                       => _x( 'Utilized Technologies', 'taxonomy general name', 'wdb-portfolio' ),
        'singular_name'              => _x( 'Utilized Technology', 'taxonomy singular name', 'wdb-portfolio' ),
        'search_items'               => __( 'Search Utilized Technologies', 'wdb-portfolio' ),
        'popular_items'              => __( 'Popular Utilized Technologies', 'wdb-portfolio' ),
        'all_items'                  => __( 'All Utilized Technologies', 'wdb-portfolio' ),
        'parent_item'                => null,
        'parent_item_colon'          => null,
        'edit_item'                  => __( 'Edit Utilized Technology', 'wdb-portfolio' ),
        'update_item'                => __( 'Update Utilized Technology', 'wdb-portfolio' ),
        'add_new_item'               => __( 'Add New Utilized Technology', 'wdb-portfolio' ),
        'new_item_name'              => __( 'New Utilized Technology Name', 'wdb-portfolio' ),
        'separate_items_with_commas' => __( 'Separate utilized technologies with commas', 'wdb-portfolio' ),
        'add_or_remove_items'        => __( 'Add or remove utilized technologies', 'wdb-portfolio' ),
        'choose_from_most_used'      => __( 'Choose from the most used utilized technologies', 'wdb-portfolio' ),
        'not_found'                  => __( 'No utilized technologies found.', 'wdb-portfolio' ),
        'menu_name'                  => __( 'Utilized Technologies', 'wdb-portfolio' ),
    );

    $args = array(
        'hierarchical'          => false,
        'labels'                => $labels,
        'show_ui'               => true,
        'show_admin_column'     => true,
        'update_count_callback' => '_update_post_term_count',
        'query_var'             => true,
        'rewrite'               => array( 'slug' => 'utilized-technologies' ),
    );

    register_taxonomy( 'technology', 'wdb_portfolio', $args );
    
    unset( $args );
    unset( $labels );

    // Add new Contributors taxonomy, NOT hierarchical (like tags)
    $labels = array(
        'name'                       => _x( 'Contributors', 'taxonomy general name', 'wdb-portfolio' ),
        'singular_name'              => _x( 'Contributor', 'taxonomy singular name', 'wdb-portfolio' ),
        'search_items'               => __( 'Search Contributors', 'wdb-portfolio' ),
        'popular_items'              => __( 'Popular Contributors', 'wdb-portfolio' ),
        'all_items'                  => __( 'All Contributors', 'wdb-portfolio' ),
        'parent_item'                => null,
        'parent_item_colon'          => null,
        'edit_item'                  => __( 'Edit Contributor', 'wdb-portfolio' ),
        'update_item'                => __( 'Update Contributor', 'wdb-portfolio' ),
        'add_new_item'               => __( 'Add New Contributor', 'wdb-portfolio' ),
        'new_item_name'              => __( 'New Contributor Name', 'wdb-portfolio' ),
        'separate_items_with_commas' => __( 'Separate contributors with commas', 'wdb-portfolio' ),
        'add_or_remove_items'        => __( 'Add or remove contributors', 'wdb-portfolio' ),
        'choose_from_most_used'      => __( 'Choose from the most used contributors', 'wdb-portfolio' ),
        'not_found'                  => __( 'No contributors found.', 'wdb-portfolio' ),
        'menu_name'                  => __( 'Contributors', 'wdb-portfolio' ),
    );

    $args = array(
        'hierarchical'          => false,
        'labels'                => $labels,
        'show_ui'               => true,
        'show_admin_column'     => true,
        'update_count_callback' => '_update_post_term_count',
        'query_var'             => true,
        'rewrite'               => array( 'slug' => 'contributor' ),
    );

    register_taxonomy( 'contributor', 'wdb_portfolio', $args );
}
// hook into the init action and call wdb_create_portfolio_taxonomies when it fires
add_action( 'init', 'wdb_create_portfolio_taxonomies', 0 );














