=== WDB Reviews & Testimonials ===
Contributors: webdevbooster
Donate link: https://alexbooster.com
Tags: custom post types, reviews, testimonials
Requires at least: 4.8.3
Tested up to: 4.8.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Custom post types plugin for reviews and testimonials.

== Description ==

No further description available at the moment.
