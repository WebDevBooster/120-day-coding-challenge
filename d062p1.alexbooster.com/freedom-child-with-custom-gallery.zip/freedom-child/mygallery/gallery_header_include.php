
<!-- 
// get_stylesheet_directory_uri() for child theme directory
// get_template_directory_uri() for parent theme directory
-->
<link rel="stylesheet" type="text/css" href="<?php echo get_stylesheet_directory_uri(); ?>/mygallery/lightbox/css/lightbox.css" />
<link rel="stylesheet" type="text/css" href="<?php echo get_stylesheet_directory_uri(); ?>/mygallery/gallery.css" />


