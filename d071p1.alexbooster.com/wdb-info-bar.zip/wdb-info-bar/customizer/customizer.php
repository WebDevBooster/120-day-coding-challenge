<?php

/**
 * Add individual sections, settings, and controls to the theme customizer
 */

function wdbIbar_customizer( $wp_customize ) {
	// Add a footer/copyright information section.
	$wp_customize->add_section( 
        'wdbib-info' , 
		array(
            'title' => __( 'WDB Info Bar', 'wdbInfoBar' ),
            'description' => 'WDB Info Bar content settings.',
		    'priority' => 160, // At the very bottom.
	    ) 
    );

    // Info Bar Message
	$wp_customize->add_setting(
	    'wdbIbar_msg_textbox',
	    array(
            'default' => 'This website is for demonstration only. All content is fictitious demo content!',
	        'sanitize_callback' => 'sanitize_text_field',
	    )
	);
	
	$wp_customize->add_control(
	    'wdbIbar_msg_textbox',
	    array(
            'label' => 'Info Bar Message',
            'description' => '1-2 sentences, ideally under 80 chars total.',
	        'section' => 'wdbib-info',
            'type' => 'textarea',
	    )
	);

	// Button Text
	$wp_customize->add_setting(
	    'wdbIbar_btn_textbox',
	    array(
	        'default' => 'More Info',
	        'sanitize_callback' => 'sanitize_text_field',
	    )
	);
	
	$wp_customize->add_control(
	    'wdbIbar_btn_textbox',
	    array(
	        'label' => 'Button Text',
	        'description' => 'For button that opens the hidden text section.',
	        'section' => 'wdbib-info',
	        'type' => 'text',
	    )
	);
        
    // Hidden Title
    $wp_customize->add_setting(
        'wdbIbar_title_textbox',
        array(
            'default' => 'Disclaimer',
            'sanitize_callback' => 'sanitize_text_field',
        )
    );

    $wp_customize->add_control(
        'wdbIbar_title_textbox',
        array(
            'label' => 'Hidden Title',
            'description' => 'The title of the hidden message.',
            'section' => 'wdbib-info',
            'type' => 'text',
        )
    );

	// Hidden Message or Disclaimer
    $wp_customize->add_setting(
	    'wdbIbar_disclaimer_textbox',
	    array(
            'default' => 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Dolores quis dolore blanditiis doloremque sint mollitia, nesciunt, aliquid ea, animi eius nobis error libero obcaecati et excepturi nam ipsam explicabo quas. Dolores quis dolore blanditiis doloremque sint mollitia.',
	        'sanitize_callback' => 'sanitize_text_field',
	    )
	);

	$wp_customize->add_control(
	    'wdbIbar_disclaimer_textbox',
	    array(
	        'label' => 'Hidden Message',
	        'description' => 'Ideally under 300 characters in total but can be longer if necessary.',
	        'section' => 'wdbib-info',
	        'type' => 'textarea',
	    )
	);

	// Call-to-action Button Text
	$wp_customize->add_setting(
	    'wdbIbar_ctabtn_textbox',
	    array(
	        'default' => 'Learn More...',
            'sanitize_callback' => 'sanitize_text_field',
	    )
	);
	
	$wp_customize->add_control(
        'wdbIbar_ctabtn_textbox',
	    array(
            'label' => 'Call-to-action Button Text',
	        'description' => 'Button at the end of the hidden message.',
	        'section' => 'wdbib-info',
	        'type' => 'text',
	    )
	);
        
    // Call-to-action Button URL
    $wp_customize->add_setting(
        'wdbIbar_url_textbox',
        array(
            'default' => 'http://alexbooster.com',
            'sanitize_callback' => 'esc_url',
        )
    );

    $wp_customize->add_control(
        'wdbIbar_url_textbox',
        array(
            'label' => 'CTA Button URL',
            'description' => 'URL to the landing page of your choice.',
            'section' => 'wdbib-info',
            'type' => 'text',
        )
    );
}
add_action( 'customize_register', 'wdbIbar_customizer' );

