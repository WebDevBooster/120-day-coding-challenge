# WDB Info Bar

Info bar with animated hidden message that opens on click.
