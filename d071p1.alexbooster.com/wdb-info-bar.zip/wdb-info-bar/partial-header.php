<?php
/* The info bar header displayed at the top of the site.
 * Actually sits in the footer, but CSS brings it to the top.
 */
?>
<aside class="wdb-infobar" role="contentinfo">
    <label>
        <input type="checkbox">
        <span class="wdb-imsg"><?php echo get_theme_mod( 'wdbIbar_msg_textbox', 'This website is for demonstration only. All content is fictitious demo content!' ); ?>
        </span>
        <span class="wdb-ibtn"><?php echo get_theme_mod( 'wdbIbar_btn_textbox', 'More Info' ); ?>
        </span>
        <div>
            <h3><?php echo get_theme_mod( 'wdbIbar_title_textbox', 'Disclaimer' ); ?>
            </h3>
            <p><?php echo get_theme_mod( 'wdbIbar_disclaimer_textbox', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Dolores quis dolore blanditiis doloremque sint mollitia, nesciunt, aliquid ea, animi eius nobis error libero obcaecati et excepturi nam ipsam explicabo quas. Dolores quis dolore blanditiis doloremque sint mollitia.' ); ?>
            </p>
            <a href="<?php echo get_theme_mod('wdbIbar_url_textbox', 'http://alexbooster.com'); ?>" target="_blank"><?php echo get_theme_mod( 'wdbIbar_ctabtn_textbox', 'Learn More&hellip;' ); ?></a>
        </div>
    </label>
</aside>


