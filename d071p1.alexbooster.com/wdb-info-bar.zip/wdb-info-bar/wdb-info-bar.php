<?php
/*
Plugin Name: WDB Info Bar
Plugin URI:  http://alexbooster.com
Description: Info bar with animated hidden message that opens on click.
Version:     1.0.0
Author:      Alex Booster
License:     GPL2
License URI: https://www.gnu.org/licenses/gpl-2.0.html
*/

/* Enqueue plugin stylesheet */
function wdbIbar_scripts() {
	// Load plugin stylesheet.
    wp_enqueue_style( 'wdbIbar-styles',  plugin_dir_url( __FILE__ ) . 'wdb-info-bar.css' );
}
add_action( 'wp_enqueue_scripts', 'wdbIbar_scripts' );

/* Output the global header */
function wdbIbar_header() {
	include('partial-header.php');
}
add_action( 'wp_footer', 'wdbIbar_header');

// Bring on the Customizer function
include( 'customizer/customizer.php');
