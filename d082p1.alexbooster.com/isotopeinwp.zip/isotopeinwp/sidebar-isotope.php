<?php
/**
 * Isotope sidebar.
 * Displays isotope filters.
 */
?>
<aside id='secondary' class='widget-area' role='complementary'>

    <section class="widget">
        <ul class="sort-clear">
            <?php // Add "Clear All" and "Sort alphabetically" buttons. ?>
            <li><button class="clear-all">Clear all</button></a></li>
            <li><button class="sort" data-sort-value="name">Sort alphabetically by title</button></li>
        </ul>
    </section>

    <section class="filter widget">
        <h2 class='widget-title'>Subject</h2>
        <ul class='filter-list' data-group='subject'>
            <?php
            /**
             * Grab all terms from the "Subject" taxonomy and wrap them in
             * a checkbox passing the term slug as the value and displaying
             * the term name as the label.
             */
            $terms = get_terms('subject');
            if ( !empty( $terms ) && !is_wp_error( $terms ) ) {
                foreach( $terms as $term) {
                    ?>
                    <li>
                        <input type='checkbox' value='.<?php echo $term->slug; ?>' id='<?php echo $term->slug; ?>'>
                        <label for='<?php echo $term->slug; ?>'><?php echo $term->name; ?></label>
                    </li>
                    <?php
                }
            }
            ?>
        </ul>
    </section><!-- .filter .widget -->

    <section class="filter widget">
        <h2 class='widget-title'>Book Author</h2>
        <ul class='filter-list' data-group='book-author'>
            <?php
            $terms = get_terms('book-author');
            if ( !empty( $terms ) && !is_wp_error( $terms ) ) {
                foreach( $terms as $term) {
                    ?>
                    <li>
                        <input type='checkbox' value='.<?php echo $term->slug; ?>' id='<?php echo $term->slug; ?>'>
                        <label for='<?php echo $term->slug; ?>'><?php echo $term->name; ?></label>
                    </li>
                    <?php
                }
            }
            ?>
        </ul>
    </section><!-- .filter .widget -->

</aside><!-- #secondary -->
