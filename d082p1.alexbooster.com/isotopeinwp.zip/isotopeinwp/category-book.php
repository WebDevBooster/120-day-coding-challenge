<?php
/**
 * Custom template for the Book category.
 * Displays all books and allows for filtering through Isotope.
*/

get_header(); ?>

<div class="wrap">
    <div id="primary" class="content-area">
		<main id="main" class="site-main isotope-container" role="main">

            <?php
    		if ( have_posts() ) : ?>
    			<?php
    			/* Start the Loop */
    			while ( have_posts() ) : the_post();

    				get_template_part( 'content', 'isotope' );

    			endwhile;
            endif; ?>

		</main><!-- #main -->
	</div><!-- #primary -->
    <?php get_sidebar('isotope'); ?>
</div><!-- .wrap -->

<?php get_footer();
