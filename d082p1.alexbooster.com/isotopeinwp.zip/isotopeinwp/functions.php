<?php

// Create two taxonomies, Subject and Author
function isotopeinwp_taxonomies() {
	// Add Subject taxonomy, make it hierarchical (like categories)
	$labels = array(
		'name'              => _x( 'Subjects', 'taxonomy general name' ),
		'singular_name'     => _x( 'Subject', 'taxonomy singular name' ),
		'search_items'      => __( 'Search Subjects' ),
		'all_items'         => __( 'All Subjects' ),
		'parent_item'       => __( 'Parent Subject' ),
		'parent_item_colon' => __( 'Parent Subject:' ),
		'edit_item'         => __( 'Edit Subject' ),
		'update_item'       => __( 'Update Subject' ),
		'add_new_item'      => __( 'Add New Subject' ),
		'new_item_name'     => __( 'New Subject Name' ),
		'menu_name'         => __( 'Subject' ),
	);
	$args = array(
		'hierarchical'      => true,
		'labels'            => $labels,
		'show_ui'           => true,
		'show_admin_column' => true,
		'query_var'         => true,
		'rewrite'           => array( 'slug' => 'subject' ),
	);
	register_taxonomy( 'subject', array( 'post' ), $args );

    // Add Author taxonomy, make it hierarchical (like categories)
	$labels = array(
		'name'              => _x( 'Book Authors', 'taxonomy general name' ),
		'singular_name'     => _x( 'Book Author', 'taxonomy singular name' ),
		'search_items'      => __( 'Search Book Authors' ),
		'all_items'         => __( 'All Book Authors' ),
		'parent_item'       => __( 'Parent Book Author' ),
		'parent_item_colon' => __( 'Parent Book Author:' ),
		'edit_item'         => __( 'Edit Book Author' ),
		'update_item'       => __( 'Update Book Author' ),
		'add_new_item'      => __( 'Add New Book Author' ),
		'new_item_name'     => __( 'New Book Author Name' ),
		'menu_name'         => __( 'Book Author' ),
	);
	$args = array(
		'hierarchical'      => true,
		'labels'            => $labels,
		'show_ui'           => true,
		'show_admin_column' => true,
		'query_var'         => true,
		'rewrite'           => array( 'slug' => 'book-author' ),
	);
	register_taxonomy( 'book-author', array( 'post' ), $args );
}
add_action( 'init', 'isotopeinwp_taxonomies', 0 );

/**
 * Load all available posts on Book index page.
 */
function isotpeinwp_index( $query ) {
    if ( !is_admin() && $query->is_main_query() ) {
        if ( is_category( 'book' ) ) {
            $query->set( 'posts_per_page', '-1' );
        }
    }
}
add_action( 'pre_get_posts', 'isotpeinwp_index' );

/**
 * Create classes from every taxonomy term applied to the current post.
 * - Creates an array $terms of terms from all taxonomies listed in $tax_array,
 * - Loops through $terms to concatenate term names,
 * - Returns a list of class names separated by spaces.
 */
function isotpeinwp_create_tax_classes() {
    $tax_array = array(
            'subject',
            'book-author'
        );
    $terms = get_the_terms( get_the_ID(), $tax_array );
    $classes = array();

    if($terms) {
        foreach ($terms as $term) {
            $classes[] = $term->slug;
        }
        $the_classes = implode(' ', $classes);
        return $the_classes;
    }
}

/**
 * If the current display is the Book category index,
 * add classes to post_class() dynamically through a filter
 * by running isotpeinwp_create_tax_classes() on each post.
 */
function isotopeinwp_add_classes( $classes ) {
    if ( is_category( 'book' ) ) {
        $classes[] = isotpeinwp_create_tax_classes();
    }
    return $classes;
}

add_filter( 'post_class', 'isotopeinwp_add_classes' );

/**
 * Enqueue jQuery, imagesLoaded, Isotope and its settings.
 */
function isotopeinwp_scripts() {
	if ( is_category( 'book' ) ) {
	    wp_register_script( 'imagesloaded', get_theme_file_uri( '/JS/libs/imagesloaded.pkgd.min.js' ), array( 'jquery' ), '4.1.1', true );
	    wp_register_script( 'isotope', get_theme_file_uri( '/JS/libs/isotope.pkgd.min.js' ), array( 'imagesloaded' ), '3.0.1', true );
	    wp_enqueue_script( 'isotopeinwp-settings', get_theme_file_uri( '/JS/isotope.settings.js' ), array( 'isotope' ), '1.0', true );
	}
}

add_action( 'wp_enqueue_scripts', 'isotopeinwp_scripts' );
