<?php
/*
Plugin Name:  WDB Login Modifier
Description:  Allows to customize the WP login page and also modify a few details in the WP admin area.
Version:      1.0.0
Author:       WebDevBooster (Alex Booster)
Author URI:   https://alexbooster.com
License:      GPL2
License URI:  https://www.gnu.org/licenses/gpl-2.0.html
Text Domain:  wdb-login-mod
Domain Path:  /languages
*/

// block direct access to this file
if ( !defined( 'ABSPATH' ) ) exit;



// if admin area
if ( is_admin() ) {

    // include dependencies
    require_once plugin_dir_path( __FILE__ ) . 'admin/admin-menu.php';
    require_once plugin_dir_path( __FILE__ ) . 'admin/settings-page.php';
    require_once plugin_dir_path( __FILE__ ) . 'admin/settings-register.php';
    require_once plugin_dir_path( __FILE__ ) . 'admin/settings-callbacks.php';
    require_once plugin_dir_path( __FILE__ ) . 'admin/settings-validate.php';

}

// include dependencies: admin and public
require_once plugin_dir_path( __FILE__ ) . 'includes/core-functions.php';


// default plugin options
function wdb_login_options_default() {

    return array(
        'custom_url'     => 'https://wordpress.org/',
        'custom_title'   => 'Powered by WordPress',
        'custom_style'   => 'disable',
        'custom_message' => '<p class="custom-message">My custom message</p>',
        'custom_footer'  => 'Special message for users',
        'custom_toolbar' => false,
        'custom_scheme'  => 'default',
    );

}



































