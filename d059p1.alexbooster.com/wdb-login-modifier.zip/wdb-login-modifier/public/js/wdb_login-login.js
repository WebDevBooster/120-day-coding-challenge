/* WDB Login Modifier JavaScript */

document.getElementById('rememberme').checked = true;
