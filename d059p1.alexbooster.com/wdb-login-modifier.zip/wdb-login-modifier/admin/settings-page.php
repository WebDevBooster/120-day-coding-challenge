<?php // WDB Login Modifier - Settings Page

// block direct access to this file
if ( !defined( 'ABSPATH' ) ) exit;


//=================================
// display the plugin settings page

// The form action below must be action="options.php"
// and the form method must always be post.
function wdb_login_display_settings_page() {

    // check if user is allowed access
    if ( ! current_user_can( 'manage_options' ) ) return;

?>

<div class="wrap">
    <h1><?php echo esc_html( get_admin_page_title() ); ?></h1>
    <form action="options.php" method="post">

        <?php

    // output security fields
    settings_fields( 'wdb_login_options' );

    // output setting sections
    do_settings_sections( 'wdb_login' );

    // submit button
    submit_button();

        ?>

    </form>
</div>

<?php

} // display the plugin settings page END




