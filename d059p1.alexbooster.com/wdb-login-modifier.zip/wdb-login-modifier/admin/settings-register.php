<?php // WDB Login Modifier - Settings Register


// block direct access to this file
if ( !defined( 'ABSPATH' ) ) exit;


// register plugin settings
function wdb_login_register_settings() {

    /*

	register_setting( 
		string   $option_group, 
		string   $option_name, 
		callable $sanitize_callback
	);

	*/

    register_setting( 
        'wdb_login_options', 
        'wdb_login_options', 
        'wdb_login_callback_validate_options' 
    ); 

    /*

	add_settings_section( 
		string   $id, 
		string   $title, 
		callable $callback, 
		string   $page
	);

	*/

    // adds settings for customizing WP login page
    add_settings_section( 
        'wdb_login_section_login', 
        'Customize Login Page', 
        'wdb_login_callback_section_login', 
        'wdb_login'
    );

    // adds settings for customizing WP admin area
    add_settings_section( 
        'wdb_login_section_admin', 
        'Customize Admin Area', 
        'wdb_login_callback_section_admin', 
        'wdb_login'
    );

    /*

	add_settings_field(
    	string   $id,
		string   $title,
		callable $callback,
		string   $page,
		string   $section = 'default',
		array    $args = []
	);

	*/

    add_settings_field(
        'custom_url',
        'Custom URL',
        'wdb_login_callback_field_text',
        'wdb_login',
        'wdb_login_section_login',
        [ 'id' => 'custom_url', 'label' => 'Custom URL for the login logo link' ]
    );

    add_settings_field(
        'custom_title',
        'Custom Title',
        'wdb_login_callback_field_text',
        'wdb_login',
        'wdb_login_section_login',
        [ 'id' => 'custom_title', 'label' => 'Custom title attribute for the logo link' ]
    );

    add_settings_field(
        'custom_style',
        'Custom Style',
        'wdb_login_callback_field_radio',
        'wdb_login',
        'wdb_login_section_login',
        [ 'id' => 'custom_style', 'label' => 'Custom CSS for the Login screen' ]
    );

    add_settings_field(
        'custom_message',
        'Custom Message',
        'wdb_login_callback_field_textarea',
        'wdb_login',
        'wdb_login_section_login',
        [ 'id' => 'custom_message', 'label' => 'Custom text and/or markup' ]
    );

    add_settings_field(
        'custom_footer',
        'Custom Footer',
        'wdb_login_callback_field_text',
        'wdb_login',
        'wdb_login_section_admin',
        [ 'id' => 'custom_footer', 'label' => 'Custom footer text' ]
    );

    add_settings_field(
        'custom_toolbar',
        'Custom Toolbar',
        'wdb_login_callback_field_checkbox',
        'wdb_login',
        'wdb_login_section_admin',
        [ 'id' => 'custom_toolbar', 'label' => 'Remove new post and comment links from the Toolbar' ]
    );

    add_settings_field(
        'custom_scheme',
        'Custom Scheme',
        'wdb_login_callback_field_select',
        'wdb_login',
        'wdb_login_section_admin',
        [ 'id' => 'custom_scheme', 'label' => 'Default color scheme for new users' ]
    );

}
add_action( 'admin_init', 'wdb_login_register_settings' );

