<?php // WDB Login Modifier - Admin Menu

// block direct access to this file
if ( !defined( 'ABSPATH' ) ) exit;


// add top-level menu item in WP admin area
function wdb_login_add_toplevel_menu() {

/* 
add_menu_page(
string   $page_title, 
string   $menu_title, 
string   $capability, 
string   $menu_slug, 
callable $function = '', 
string   $icon_url = '', 
int      $position = null 
)
*/

add_menu_page(
'WDB Login Modifier Settings',
'WDB Login Modifier',
'manage_options',
'wdb_login',
'wdb_login_display_settings_page',
'dashicons-admin-generic',
null
);

}
add_action( 'admin_menu', 'wdb_login_add_toplevel_menu' );
// add top-level menu item in WP admin area END


